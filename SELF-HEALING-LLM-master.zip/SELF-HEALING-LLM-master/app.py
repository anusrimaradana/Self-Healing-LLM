"""
NaTGen Web Interface
Entry point for the live demo submission.
Runs on port 5000 (the generated apps run on 5001).
"""

import json
import os

from flask import Flask, jsonify, render_template, request
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/generate", methods=["POST"])
def generate():
    data = request.json
    if not data or not data.get("prompt", "").strip():
        return jsonify({"error": "No prompt provided"}), 400

    user_prompt = data["prompt"].strip()

    try:
        from pipeline import run_pipeline
        result = run_pipeline(user_prompt, max_repairs=3)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e), "success": False}), 500


@app.route("/generate-app", methods=["POST"])
def generate_app_route():
    """Generate a runnable Flask app from a validated schema."""
    data = request.json
    if not data or "schema" not in data:
        return jsonify({"error": "No schema provided"}), 400

    try:
        from schemas import AppSchema
        from runtime.generator import generate_app

        schema = AppSchema.model_validate(data["schema"])
        safe_name = schema.app_name.lower().replace(" ", "_").replace("-", "_")
        output_dir = f"generated_apps/{safe_name}"
        generate_app(schema, output_dir)

        return jsonify({
            "success": True,
            "output_dir": output_dir,
            "message": f"App generated at {output_dir}/"
        })
    except Exception as e:
        return jsonify({"error": str(e), "success": False}), 500


if __name__ == "__main__":
    os.makedirs("generated_apps", exist_ok=True)
    app.run(debug=True, port=5000)
