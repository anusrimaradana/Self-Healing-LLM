import os
import re
from jinja2 import Template
from schemas import AppSchema

# Maps Pydantic/schema types to SQLAlchemy column types
TYPE_MAP = {
    "string": "db.String(255)",
    "integer": "db.Integer",
    "boolean": "db.Boolean",
    "float": "db.Float",
    "datetime": "db.DateTime",
}

TEMPLATES_DIR = os.path.join(os.path.dirname(__file__), "templates")


def _render(template_file: str, output_path: str, **kwargs):
    """Render a Jinja2 template and write the result to output_path."""
    with open(os.path.join(TEMPLATES_DIR, template_file), "r") as f:
        tpl = Template(f.read())
    rendered = tpl.render(**kwargs)
    with open(output_path, "w") as f:
        f.write(rendered)


def sanitize_func_name(path: str, method: str) -> str:
    """
    Sanitize endpoint path and method into a valid Python identifier.
    e.g. GET /payroll/{employee_id} -> api_get_payroll_employee_id
    """
    clean_path = re.sub(r"[^a-zA-Z0-9_]", "_", path)
    clean_path = re.sub(r"_+", "_", clean_path).strip("_")
    return f"api_{method.lower()}_{clean_path}"


def generate_app(schema: AppSchema, output_dir: str = "generated_app") -> str:
    """
    Walk the AppSchema and render all app files via Jinja2.
    Zero LLM calls — pure deterministic template rendering.

    Outputs:
        {output_dir}/app.py           Flask routes (pages + API endpoints)
        {output_dir}/models.py        SQLAlchemy models
        {output_dir}/templates/       HTML pages
        {output_dir}/requirements.txt
    """
    # ── Setup directories ─────────────────────────────────────────────────────
    templates_out = os.path.join(output_dir, "templates")
    os.makedirs(templates_out, exist_ok=True)

    # ── Prepare table data ───────────────────────────────────────────────────
    tables_data = []
    for table in schema.tables:
        cols = [
            {
                "name": col.name,
                "type_mapped": TYPE_MAP.get(col.type, "db.String(255)"),
                "foreign_key": col.foreign_key,
            }
            for col in table.columns
        ]
        tables_data.append({"name": table.name, "columns": cols})

    # ── Prepare endpoints data with sanitized func_name ───────────────────────
    endpoints_data = []
    for ep in schema.endpoints:
        func_name = sanitize_func_name(ep.path, ep.method)
        endpoints_data.append({
            "method": ep.method,
            "path": ep.path,
            "request_fields": ep.request_fields,
            "response_fields": ep.response_fields,
            "func_name": func_name,
        })

    # ── Generate app.py ───────────────────────────────────────────────────────
    _render(
        "app_py.j2",
        os.path.join(output_dir, "app.py"),
        app_name=schema.app_name,
        pages=schema.pages,
        endpoints=endpoints_data,
        tables=schema.tables,
    )

    # ── Generate models.py ────────────────────────────────────────────────────
    _render(
        "models_py.j2",
        os.path.join(output_dir, "models.py"),
        tables=tables_data,
    )

    # ── Generate base.html ────────────────────────────────────────────────────
    _render(
        "base_html.j2",
        os.path.join(templates_out, "base.html"),
        app_name=schema.app_name,
        pages=schema.pages,
    )

    # ── Generate one HTML page per UIPage ─────────────────────────────────────
    for page in schema.pages:
        filename = page.name.lower().replace(" ", "_") + ".html"
        _render(
            "page_html.j2",
            os.path.join(templates_out, filename),
            page=page,
            app_name=schema.app_name,
            pages=schema.pages,
        )

    # ── Generate requirements.txt ─────────────────────────────────────────────
    with open(os.path.join(output_dir, "requirements.txt"), "w") as f:
        f.write("flask\nflask-sqlalchemy\n")

    print(f"[SUCCESS] App generated at: {os.path.abspath(output_dir)}/")
    return output_dir
