import json
import os
import time

from dotenv import load_dotenv
from jinja2 import Template
from openai import OpenAI, BadRequestError, RateLimitError
from pydantic import ValidationError

from schemas import AppSchema

load_dotenv()


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

def render_prompt(template_name: str, **kwargs) -> str:
    """Load a Jinja2 template from prompts/ and render it."""
    with open(f"prompts/{template_name}", "r") as f:
        template = Template(f.read())
    return template.render(**kwargs)


def _call_openai(prompt: str, model: str = "llama-3.1-8b-instant", max_api_retries: int = 5) -> str:
    """
    Call Groq via its OpenAI-compatible endpoint with RateLimit (429) backoff.
    Handles server-side json_object validation errors gracefully by extracting
    partial/failed generation or retrying without strict json_object format.
    """
    client = OpenAI(
        api_key=os.environ.get("GROQ_API_KEY"),
        base_url="https://api.groq.com/openai/v1",
    )
    for attempt in range(max_api_retries):
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"},
            )
            return response.choices[0].message.content
        except RateLimitError as e:
            if attempt == max_api_retries - 1:
                raise e
            time.sleep(8 * (attempt + 1))
        except BadRequestError as err:
            if hasattr(err, "body") and isinstance(err.body, dict):
                failed_gen = err.body.get("error", {}).get("failed_generation")
                if failed_gen:
                    return failed_gen

            try:
                response = client.chat.completions.create(
                    model=model,
                    messages=[{"role": "user", "content": prompt}],
                )
                return response.choices[0].message.content
            except RateLimitError as e:
                if attempt == max_api_retries - 1:
                    raise e
                time.sleep(8 * (attempt + 1))


# ──────────────────────────────────────────────
# Stage 1: Intent Extraction
# ──────────────────────────────────────────────

def extract_intent(user_prompt: str) -> dict:
    """
    Stage 1 — Parse raw user prompt into structured intent dict.
    """
    prompt = render_prompt("intent_extraction.j2", user_prompt=user_prompt)
    raw = _call_openai(prompt)
    try:
        return json.loads(raw)
    except Exception:
        return {
            "app_name": "Generated App",
            "features": [user_prompt],
            "roles": ["admin", "user"],
            "entities": ["item"],
        }


# ──────────────────────────────────────────────
# Stage 2: Schema Generation
# ──────────────────────────────────────────────

def generate_schema_raw(intent: dict, user_prompt: str) -> str:
    """
    Stage 2 — Generate raw AppSchema JSON string from intent and prompt.
    """
    context = (
        f"Original app description: {user_prompt}\n\n"
        f"Extracted intent:\n{json.dumps(intent, indent=2)}"
    )
    prompt = render_prompt("schema_generation.j2", user_prompt=context)
    return _call_openai(prompt)


# ──────────────────────────────────────────────
# Stage 3 & 4: Validate + Repair Loop
# ──────────────────────────────────────────────

def run_pipeline(user_prompt: str, max_repairs: int = 3) -> dict:
    """
    Full 4-stage pipeline:
      1. Intent extraction
      2. Schema generation
      3. Pydantic validation
      4. Surgical field-level repair on validation failure (up to max_repairs times)
    """
    from repair import repair_schema

    start = time.time()
    retries = 0

    # Stage 1
    intent = extract_intent(user_prompt)

    # Stage 2
    raw_json = generate_schema_raw(intent, user_prompt)

    # Stage 3 & 4: Validate & Repair Loop
    last_error = None
    for attempt in range(max_repairs + 1):
        try:
            schema = AppSchema.model_validate_json(raw_json)
            return {
                "success": True,
                "schema": schema.model_dump(),
                "retries": retries,
                "latency": round(time.time() - start, 2),
            }
        except Exception as e:
            last_error = e
            if attempt < max_repairs:
                retries += 1
                raw_json = repair_schema(raw_json, e)

    return {
        "success": False,
        "error": str(last_error),
        "retries": retries,
        "latency": round(time.time() - start, 2),
    }
