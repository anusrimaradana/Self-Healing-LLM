import json
import os
import time

from jinja2 import Template
from openai import OpenAI, BadRequestError, RateLimitError
from pydantic import ValidationError


# ──────────────────────────────────────────────
# Error Parser
# ──────────────────────────────────────────────

def parse_validation_errors(error: Exception) -> list[dict]:
    """
    Extract field-level error details from a Pydantic ValidationError or parse exception.
    """
    if not isinstance(error, ValidationError):
        return [{"field": "root", "message": str(error), "type": "parse_error"}]

    errors = []
    for e in error.errors():
        field_path = " -> ".join(str(loc) for loc in e["loc"]) if e["loc"] else "root"
        errors.append({
            "field": field_path,
            "message": e["msg"],
            "type": e["type"],
        })
    return errors


# ──────────────────────────────────────────────
# Repair Engine
# ──────────────────────────────────────────────

def repair_schema(raw_json: str, error: Exception, max_api_retries: int = 5) -> str:
    """
    Scoped repair: given a broken JSON string and validation error,
    renders refinement prompt with broken fields, calls LLM, returns repaired JSON.
    Includes RateLimitError backoff.
    """
    from schemas import AppSchema

    errors = parse_validation_errors(error)
    json_schema = json.dumps(AppSchema.model_json_schema(), indent=2)

    with open("prompts/refinement.j2", "r") as f:
        template = Template(f.read())

    prompt = template.render(
        current_schema=raw_json,
        errors=json.dumps(errors, indent=2),
        json_schema=json_schema,
    )

    client = OpenAI(
        api_key=os.environ.get("GROQ_API_KEY"),
        base_url="https://api.groq.com/openai/v1",
    )
    for attempt in range(max_api_retries):
        try:
            response = client.chat.completions.create(
                model="llama-3.1-8b-instant",
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"},
            )
            return response.choices[0].message.content
        except RateLimitError as e:
            if attempt == max_api_retries - 1:
                raise e
            time.sleep(8 * (attempt + 1))
        except BadRequestError as err:
            if hasattr(err, "body") and isinstance(err.body, dict):
                failed_gen = err.body.get("error", {}).get("failed_generation")
                if failed_gen:
                    return failed_gen

            try:
                response = client.chat.completions.create(
                    model="llama-3.1-8b-instant",
                    messages=[{"role": "user", "content": prompt}],
                )
                return response.choices[0].message.content
            except RateLimitError as e:
                if attempt == max_api_retries - 1:
                    raise e
                time.sleep(8 * (attempt + 1))
