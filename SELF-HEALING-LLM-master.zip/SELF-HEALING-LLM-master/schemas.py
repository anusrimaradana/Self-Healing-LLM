from pydantic import BaseModel, field_validator
from typing import List, Optional, Literal, Dict


class UIComponent(BaseModel):
    type: Literal["form", "table", "chart", "card"]
    label: str
    fields: List[str]

    @field_validator("type", mode="before")
    @classmethod
    def normalize_ui_type(cls, v):
        if isinstance(v, str):
            v_lower = v.lower().strip()
            mapping = {
                "form": "form", "input": "form", "button": "form", "container": "form",
                "table": "table", "list": "table", "grid": "table",
                "chart": "chart", "graph": "chart", "analytics": "chart",
                "card": "card", "summary": "card", "metric": "card", "text": "card"
            }
            return mapping.get(v_lower, v_lower)
        return v


class UIPage(BaseModel):
    name: str
    components: List[UIComponent]


class APIEndpoint(BaseModel):
    method: Literal["GET", "POST", "PUT", "DELETE"]
    path: str
    request_fields: List[str]
    response_fields: List[str]

    @field_validator("method", mode="before")
    @classmethod
    def normalize_method(cls, v):
        if isinstance(v, str):
            return v.upper().strip()
        return v


class DBColumn(BaseModel):
    name: str
    type: Literal["string", "integer", "boolean", "float", "datetime"]
    foreign_key: Optional[str] = None

    @field_validator("type", mode="before")
    @classmethod
    def normalize_column_type(cls, v):
        if isinstance(v, str):
            v_lower = v.lower().strip()
            mapping = {
                "int": "integer", "integer": "integer", "bigint": "integer", "smallint": "integer",
                "str": "string", "string": "string", "text": "string", "varchar": "string", "char": "string",
                "bool": "boolean", "boolean": "boolean",
                "float": "float", "double": "float", "decimal": "float", "number": "float", "numeric": "float",
                "date": "datetime", "datetime": "datetime", "timestamp": "datetime", "time": "datetime"
            }
            return mapping.get(v_lower, v_lower)
        return v


class DBTable(BaseModel):
    name: str
    columns: List[DBColumn]


class AuthConfig(BaseModel):
    roles: List[str]
    permissions: Dict[str, List[str]]


class AppSchema(BaseModel):
    app_name: str
    pages: List[UIPage]
    endpoints: List[APIEndpoint]
    tables: List[DBTable]
    auth: AuthConfig
