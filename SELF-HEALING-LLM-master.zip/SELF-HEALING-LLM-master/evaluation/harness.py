"""
Evaluation Harness — NaTGen Self-Healing Pipeline
Runs all 20 prompts (10 real-world + 10 adversarial) through run_pipeline()
and reports: success rate, average retries, average latency, failure types.
"""

import json
import os
import sys
import time
from datetime import datetime

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pipeline import run_pipeline


def run_harness(prompts_file: str = None) -> dict:
    if prompts_file is None:
        prompts_file = os.path.join(os.path.dirname(__file__), "prompts.json")

    with open(prompts_file) as f:
        data = json.load(f)

    all_prompts = [
        ("real_world", p) for p in data["real_world"]
    ] + [
        ("adversarial", p) for p in data["adversarial"]
    ]

    results = []
    print(f"\n{'=' * 70}")
    print(f"  NaTGen Evaluation Harness  --  {len(all_prompts)} prompts")
    print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'=' * 70}\n")

    for i, (category, prompt) in enumerate(all_prompts, 1):
        short = prompt[:60] + ("..." if len(prompt) > 60 else "")
        print(f"[{i:02d}/{len(all_prompts)}] [{category}] {short}")

        result = run_pipeline(prompt, max_repairs=3)

        status = "[PASS]" if result["success"] else "[FAIL]"
        print(f"      {status}  |  retries={result['retries']}  |  latency={result['latency']}s")
        if not result["success"]:
            print(f"      error: {result.get('error', '')[:80]}")

        results.append({
            "index": i,
            "category": category,
            "prompt": prompt,
            **result,
        })
        print()
        time.sleep(2)  # Respect API rate limits

    # ── Summary Stats ─────────────────────────────────────────────────────────
    successes = [r for r in results if r["success"]]
    failures = [r for r in results if not r["success"]]
    real_results = [r for r in results if r["category"] == "real_world"]
    adv_results = [r for r in results if r["category"] == "adversarial"]

    def avg(lst, key):
        return round(sum(r[key] for r in lst) / len(lst), 2) if lst else 0

    summary = {
        "timestamp": datetime.now().isoformat(),
        "total": len(results),
        "success_count": len(successes),
        "failure_count": len(failures),
        "success_rate": f"{len(successes) / len(results) * 100:.1f}%",
        "avg_retries": avg(results, "retries"),
        "avg_latency_s": avg(results, "latency"),
        "real_world_success_rate": f"{len([r for r in real_results if r['success']]) / len(real_results) * 100:.1f}%" if real_results else "N/A",
        "adversarial_success_rate": f"{len([r for r in adv_results if r['success']]) / len(adv_results) * 100:.1f}%" if adv_results else "N/A",
        "results": results,
    }

    print(f"{'=' * 70}")
    print(f"  SUMMARY")
    print(f"{'-' * 70}")
    print(f"  Total prompts      : {summary['total']}")
    print(f"  Success rate       : {summary['success_rate']}  ({summary['success_count']} passed, {summary['failure_count']} failed)")
    print(f"  Real-world SR      : {summary['real_world_success_rate']}")
    print(f"  Adversarial SR     : {summary['adversarial_success_rate']}")
    print(f"  Avg retries/prompt : {summary['avg_retries']}")
    print(f"  Avg latency        : {summary['avg_latency_s']}s")
    print(f"{'=' * 70}\n")

    # Write results to file
    out_path = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"  Results saved -> {out_path}\n")

    return summary


if __name__ == "__main__":
    run_harness()
